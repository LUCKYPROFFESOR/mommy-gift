import { useState, useEffect } from 'react';

export default function PrincessPage() {
  const [gameStarted, setGameStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [currentMessage, setCurrentMessage] = useState('');
  const [messageVisible, setMessageVisible] = useState(false);
  const [hearts, setHearts] = useState<Array<{id: number, x: number, y: number, collected: boolean}>>([]);
  const [showLevelComplete, setShowLevelComplete] = useState(false);
  const [debugMode, setDebugMode] = useState(false);
  const [debugInfo, setDebugInfo] = useState({
    heartsGenerated: 0,
    heartsCollected: 0,
    levelStartTime: 0,
    clickCount: 0
  });

  const messages = [
    "You are the sunshine that brightens my darkest days 💘",
    "In a world full of chaos, you are my peace 💞", 
    "Your smile is my favorite view in the universe 💓",
    "Princess, you make ordinary moments feel magical 🥰",
    "You are the melody my heart has been searching for 💕",
    "Every day with you feels like a beautiful dream 💖",
    "You are my greatest adventure and my safest place 💝",
    "Forever isn't long enough when I'm with you 💫"
  ];

  const levelMessages = [
    "Welcome to our love story! 💕",
    "You're getting warmer, my princess! 💖",
    "Your beauty lights up this game! ✨",
    "Almost there, sweetheart! 💘",
    "You're amazing at this! 🥰",
    "Final level, my love! 💫"
  ];

  const startGame = () => {
    setGameStarted(true);
    setScore(0);
    setLevel(1);
    generateHearts();
  };

  const generateHearts = () => {
    const newHearts = [];
    const heartsPerLevel = Math.min(3 + level, 8);
    
    for (let i = 0; i < heartsPerLevel; i++) {
      newHearts.push({
        id: i,
        x: Math.random() * 80 + 10, // 10% to 90% of screen width
        y: Math.random() * 60 + 20, // 20% to 80% of screen height
        collected: false
      });
    }
    setHearts(newHearts);
    
    // Update debug info
    setDebugInfo(prev => ({
      ...prev,
      heartsGenerated: heartsPerLevel,
      heartsCollected: 0,
      levelStartTime: Date.now(),
      clickCount: 0
    }));
  };

  const collectHeart = (heartId: number) => {
    console.log('Heart clicked:', heartId);
    
    setHearts(prev => {
      console.log('Current hearts before update:', prev);
      const updatedHearts = prev.map(heart => 
        heart.id === heartId ? { ...heart, collected: true } : heart
      );
      console.log('Hearts after update:', updatedHearts);
      
      // Check if all hearts collected after this update
      const remainingHearts = updatedHearts.filter(h => !h.collected);
      console.log('Remaining hearts:', remainingHearts.length);
      if (remainingHearts.length === 0) {
        setTimeout(() => {
          completeLevel();
        }, 500);
      }
      
      return updatedHearts;
    });
    setScore(prev => prev + 10);
    
    // Update debug info
    setDebugInfo(prev => ({
      ...prev,
      heartsCollected: prev.heartsCollected + 1,
      clickCount: prev.clickCount + 1
    }));
  };

  const completeLevel = () => {
    setShowLevelComplete(true);
    const messageIndex = Math.min(level - 1, messages.length - 1);
    setCurrentMessage(messages[messageIndex]);
    setMessageVisible(true);
    
    setTimeout(() => {
      if (level >= 6) {
        // Game completed
        setCurrentMessage("Congratulations, Princess! You've won my heart completely! 💖");
      } else {
        setLevel(prev => prev + 1);
        setShowLevelComplete(false);
        setMessageVisible(false);
        generateHearts();
      }
    }, 3000);
  };

  const resetGame = () => {
    setGameStarted(false);
    setScore(0);
    setLevel(1);
    setHearts([]);
    setShowLevelComplete(false);
    setMessageVisible(false);
    setCurrentMessage('');
    setDebugInfo({
      heartsGenerated: 0,
      heartsCollected: 0,
      levelStartTime: 0,
      clickCount: 0
    });
  };

  const toggleDebugMode = () => {
    setDebugMode(!debugMode);
  };

  const skipLevel = () => {
    if (debugMode) {
      completeLevel();
    }
  };

  const addScore = (points: number) => {
    if (debugMode) {
      setScore(prev => prev + points);
    }
  };

  const generateMoreHearts = () => {
    if (debugMode) {
      const additionalHearts: Array<{id: number, x: number, y: number, collected: boolean}> = [];
      const startId = hearts.length;
      
      for (let i = 0; i < 3; i++) {
        additionalHearts.push({
          id: startId + i,
          x: Math.random() * 80 + 10,
          y: Math.random() * 60 + 20,
          collected: false
        });
      }
      
      setHearts(prev => [...prev, ...additionalHearts]);
      setDebugInfo(prev => ({
        ...prev,
        heartsGenerated: prev.heartsGenerated + 3
      }));
    }
  };

  // Generate hearts when level changes
  useEffect(() => {
    if (gameStarted && level > 1) {
      generateHearts();
    }
  }, [level]);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Game UI */}
      {gameStarted && (
        <div className="absolute top-4 left-4 z-20 bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
          <div className="font-cute text-lg font-bold" style={{ color: 'hsl(var(--princess-pink))' }}>
            Score: {score}
          </div>
          <div className="font-cute text-lg font-bold" style={{ color: 'hsl(var(--deep-magenta))' }}>
            Level: {level}
          </div>
          <button 
            onClick={resetGame}
            className="mt-2 px-4 py-2 bg-pink-300 hover:bg-pink-400 text-white rounded-lg font-cute text-sm transition-all duration-300"
          >
            Reset Game
          </button>
        </div>
      )}

      {/* Debug Toggle Button */}
      <button
        onClick={toggleDebugMode}
        className="absolute top-4 right-4 z-20 px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-cute text-xs transition-all duration-300"
      >
        {debugMode ? 'Hide Debug' : 'Debug Mode'}
      </button>

      {/* Debug Panel */}
      {debugMode && (
        <div className="absolute top-16 right-4 z-20 bg-black/80 backdrop-blur-sm rounded-2xl p-4 shadow-lg text-white max-w-xs">
          <h3 className="font-cute text-lg font-bold mb-3 text-center">Debug Panel</h3>
          
          {/* Debug Info */}
          <div className="space-y-2 mb-4 text-sm">
            <div>Hearts Generated: {debugInfo.heartsGenerated}</div>
            <div>Hearts Collected: {debugInfo.heartsCollected}</div>
            <div>Total Clicks: {debugInfo.clickCount}</div>
            <div>Hearts Remaining: {hearts.filter(h => !h.collected).length}</div>
            <div>Level Time: {debugInfo.levelStartTime ? Math.floor((Date.now() - debugInfo.levelStartTime) / 1000) + 's' : '0s'}</div>
          </div>

          {/* Debug Controls */}
          <div className="space-y-2">
            <button 
              onClick={skipLevel}
              className="w-full px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-cute text-xs transition-all duration-300"
            >
              Skip Level
            </button>
            
            <button 
              onClick={() => addScore(100)}
              className="w-full px-3 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-cute text-xs transition-all duration-300"
            >
              +100 Score
            </button>
            
            <button 
              onClick={generateMoreHearts}
              className="w-full px-3 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-cute text-xs transition-all duration-300"
            >
              Add 3 Hearts
            </button>
          </div>

          {/* Hearts Debug Info */}
          <div className="mt-4 text-xs">
            <div className="font-bold mb-1">Heart Positions:</div>
            <div className="max-h-20 overflow-y-auto space-y-1">
              {hearts.map(heart => (
                <div key={heart.id} className={heart.collected ? 'text-gray-500' : 'text-white'}>
                  #{heart.id}: ({Math.round(heart.x)}%, {Math.round(heart.y)}%) {heart.collected ? '✓' : '○'}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Collectible Hearts */}
      {gameStarted && hearts.map(heart => (
        !heart.collected && (
          <div
            key={heart.id}
            className="absolute cursor-pointer transform hover:scale-110 transition-all duration-300 animate-bounce-gentle"
            style={{ 
              left: `${heart.x}%`, 
              top: `${heart.y}%`,
              fontSize: '2rem',
              zIndex: 50,
              padding: '10px',
              userSelect: 'none'
            }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              collectHeart(heart.id);
            }}
            onMouseDown={(e) => e.preventDefault()}
          >
            💖
          </div>
        )
      ))}

      {/* Background decorative floating hearts */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-6xl opacity-20 animate-float" style={{ color: 'hsl(var(--princess-pink))' }}>💕</div>
        <div className="absolute top-32 right-16 text-4xl opacity-25 animate-bounce-gentle" style={{ color: 'hsl(var(--princess-pink))', animationDelay: '0.5s' }}>💖</div>
        <div className="absolute bottom-20 left-20 text-5xl opacity-15 animate-float" style={{ color: 'hsl(var(--princess-pink))', animationDelay: '1s' }}>💘</div>
        <div className="absolute bottom-40 right-10 text-3xl opacity-30 animate-bounce-gentle" style={{ color: 'hsl(var(--princess-pink))', animationDelay: '1.5s' }}>💓</div>
      </div>

      {/* Main content container */}
      <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
        <div className="bg-white/40 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12 max-w-2xl w-full text-center border border-white/20">
          
          {!gameStarted ? (
              // Welcome Screen
              <>
                <div className="mb-8">
                  <div className="text-8xl md:text-9xl animate-float filter drop-shadow-lg">❤️</div>
                </div>

                <h1 className="font-handwriting text-4xl md:text-6xl mb-4 animate-pulse-glow" style={{ color: 'hsl(var(--princess-pink))' }}>
                  Hi Princess 💕
                </h1>

                <div className="font-cute text-lg md:text-xl mb-8 leading-relaxed" style={{ color: 'hsl(var(--deep-magenta))' }}>
                  <p className="font-semibold italic" style={{ color: 'hsl(var(--princess-pink))' }}>
                    "Your beauty shines brighter than all the stars in the sky, and your grace makes even flowers jealous of your elegance." ✨
                  </p>
                </div>

                <button 
                  onClick={startGame}
                  className="group bg-gradient-to-r text-white font-cute font-semibold px-8 py-4 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 mb-6 border-2 border-white/30 hover:border-white/50"
                  style={{ 
                    background: 'linear-gradient(to right, hsl(var(--blush-pink)), hsl(var(--princess-pink)))',
                    color: 'white'
                  }}
                >
                  <span className="flex items-center justify-center gap-2">
                    Start Love Game 💌
                    <span className="group-hover:animate-bounce-gentle">✨</span>
                  </span>
                </button>

                <div className="font-cute text-base" style={{ color: 'hsl(var(--deep-magenta))' }}>
                  Collect all the hearts to unlock romantic messages! 💕
                </div>

                <div className="mt-8">
                  <h2 className="font-handwriting text-3xl md:text-4xl font-bold animate-pulse-glow" style={{ color: 'hsl(var(--princess-pink))' }}>
                    I Love You 💖
                  </h2>
                </div>
              </>
            ) : (
              // Game Screen
              <>
                <div className="mb-8">
                  <div className="text-6xl md:text-7xl animate-float filter drop-shadow-lg">👑</div>
                </div>

                <h2 className="font-handwriting text-3xl md:text-4xl mb-6 animate-pulse-glow" style={{ color: 'hsl(var(--princess-pink))' }}>
                  {showLevelComplete ? "Level Complete!" : `Level ${level}`}
                </h2>

                {!showLevelComplete && (
                  <div className="font-cute text-lg mb-6" style={{ color: 'hsl(var(--deep-magenta))' }}>
                    Collect all {hearts.length} hearts to continue! 💕
                  </div>
                )}

                {/* Message display */}
                <div className="min-h-[4rem] flex items-center justify-center mb-6">
                  <p 
                    className={`font-handwriting text-xl md:text-2xl font-bold transition-all duration-500 ease-out ${
                      messageVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-4'
                    }`}
                    style={{ color: 'hsl(var(--princess-pink))' }}
                  >
                    {currentMessage}
                  </p>
                </div>

                {level >= 6 && showLevelComplete && (
                  <div className="mt-8">
                    <h2 className="font-handwriting text-3xl md:text-4xl font-bold animate-pulse-glow" style={{ color: 'hsl(var(--princess-pink))' }}>
                      I Love You Forever 💖
                    </h2>
                    <button 
                      onClick={resetGame}
                      className="mt-4 px-6 py-3 bg-gradient-to-r text-white font-cute font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                      style={{ 
                        background: 'linear-gradient(to right, hsl(var(--blush-pink)), hsl(var(--princess-pink)))'
                      }}
                    >
                      Play Again 💕
                    </button>
                  </div>
                )}
              </>
            )}

            {/* Decorative elements */}
            <div className="flex justify-center space-x-4 mt-8 text-2xl opacity-60">
              <span className="animate-pulse" style={{ animationDelay: '0s' }}>💝</span>
              <span className="animate-pulse" style={{ animationDelay: '0.5s' }}>🌸</span>
              <span className="animate-pulse" style={{ animationDelay: '1s' }}>💐</span>
              <span className="animate-pulse" style={{ animationDelay: '1.5s' }}>🦋</span>
              <span className="animate-pulse" style={{ animationDelay: '2s' }}>✨</span>
            </div>
          </div>
        </div>
      </div>
  );
}
